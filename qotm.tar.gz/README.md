# (Obscure) Quote of the Moment Service

Supplemental material for Kubernetes Training.

```
kubectl apply -f https://raw.githubusercontent.com/datawire/qotm/master/kubernetes/qotm-deployment.yaml
kubectl apply -f https://raw.githubusercontent.com/datawire/qotm/master/kubernetes/qotm-service.yaml
```

# License

Licensed under Apache 2.0. Please see [LICENSE](LICENSE) for details.
